import 'package:get/get.dart';
class MyLanguage extends Translations {
  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys =>{

    'en': {


    }
    ,
    'fr':{


    },
    'ar' : {

    }

  };
}