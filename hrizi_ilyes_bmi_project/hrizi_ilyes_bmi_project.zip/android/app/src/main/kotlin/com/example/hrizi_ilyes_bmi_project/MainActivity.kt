package com.example.hrizi_ilyes_bmi_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
